#### `argument_name`

multiline
argument description

* Is required: yes
* Is array: no
* Default: `NULL`
